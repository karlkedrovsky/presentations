<?php

namespace Drupal\shagnasty\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'BooyahBlock' block.
 *
 * @Block(
 *  id = "booyah_block",
 *  admin_label = @Translation("Booyah block"),
 * )
 */
class BooyahBlock extends BlockBase implements ContainerFactoryPluginInterface {

  protected $shagnastyService;

  public function __construct(array $configuration, $plugin_id, $plugin_definition, $shagnastyService) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->shagnastyService = $shagnastyService;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('shagnasty.booyah')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $build['booyah_block']['#markup'] = $this->shagnastyService->booyah();

    return $build;
  }

}
