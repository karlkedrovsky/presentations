<?php

namespace Drupal\shagnasty;


/**
 * Class BooyahService.
 *
 * @package Drupal\shagnasty
 */
class BooyahService implements BooyahServiceInterface {

  /**
   * Constructor.
   */
  public function __construct() {

  }

  public function booyah() {
    return "Booyah!!";
  }

}
