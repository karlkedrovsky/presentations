<?php

namespace Drupal\shagnasty;

/**
 * Interface BooyahServiceInterface.
 *
 * @package Drupal\shagnasty
 */
interface BooyahServiceInterface {

  public function booyah();

}
