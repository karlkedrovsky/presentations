<?php

namespace Drupal\bolivar\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class GreetingController.
 *
 * @package Drupal\bolivar\Controller
 */
class GreetingController extends ControllerBase {

  protected $shagnastyService;

  public function __construct($shagnastyService) {
    $this->shagnastyService = $shagnastyService;
  }

  public static function create(ContainerInterface $container) {
    return new static($container->get('shagnasty.booyah'));
  }

  /**
   * Hello.
   # '#markup' => $this->t('Implement method: hello with parameter(s): $name'),
   *
   * @return string
   *   Return Hello string.
   */
  public function hello($name) {
    return [
      '#type' => 'markup',
      '#markup' => '<h2>Hello ' . $name . '</h2>',
    ];
  }

  public function hi($name) {
    return [
      '#theme' => 'foo',
      '#name' => $name . ' - ' . $this->shagnastyService->booyah(),
    ];
  }

}
